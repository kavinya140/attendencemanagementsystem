import java.util.ArrayList;
import java.util.List;

public class Attendance {
    List<Student> students = new ArrayList<>();

    public void addStudent(int id, String name) {
        students.add(new Student(id, name));
    }

    public void markAttendance(int id) {
        for (Student s : students) {
            if (s.id == id) {
                s.markPresent();
                System.out.println(s.name + " marked as present.");
                return;
            }
        }
        System.out.println("Student not found.");
    }

    public void showReport() {
        System.out.println("\nAttendance Report:");
        for (Student s : students) {
            System.out.println(s);
        }
    }
}
