import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Attendance attendance = new Attendance();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Attendance Management System ---");
            System.out.println("1. Add Student");
            System.out.println("2. Mark Attendance");
            System.out.println("3. View Report");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // Clear input buffer

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Student Name: ");
                    String name = sc.nextLine();
                    attendance.addStudent(id, name);
                    break;
                case 2:
                    System.out.print("Enter Student ID to mark present: ");
                    int markId = sc.nextInt();
                    attendance.markAttendance(markId);
                    break;
                case 3:
                    attendance.showReport();
                    break;
                case 4:
                    System.out.println("Exiting Program...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 4);

        sc.close();
    }
}
