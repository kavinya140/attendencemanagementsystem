public class Student {
    int id;
    String name;
    boolean isPresent;

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
        this.isPresent = false;
    }

    public void markPresent() {
        this.isPresent = true;
    }

    @Override
    public String toString() {
        return id + " - " + name + " - " + (isPresent ? "Present" : "Absent");
    }
}
