# 📚 Attendance Management System (Java Console App)

This is a simple **console-based Java application** that allows you to manage student attendance.

## 🚀 Features
- ✅ Add new students
- 📝 Mark student attendance
- 📄 View attendance report

## 🛠 How to Run

### Compile
```bash
javac -d bin src/*.java
```

### Run
```bash
java -cp bin Main
```

## 📜 License

This project is licensed under the MIT License.
